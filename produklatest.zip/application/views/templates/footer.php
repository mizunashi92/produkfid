
      <!-- Bottom Footer -->
      <section class="padding background-dark full-width">
        <div class="s-12 l-6">
         <p class="text-size-12"><a href="http://www.gsxcreativeweb.com">Copyright 2018, Univision Support System</a></p>
          <p class="text-size-12"></p>
        </div>
        <div class="s-12 l-6">
          <a class="right text-size-12" title="Univision Allianz"></a>
        </div>
      </section>
    </footer>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/responsee.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/owl-carousel/owl.carousel.js"></script>
    <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/template-scripts.js"></script>
  </body>
</html>